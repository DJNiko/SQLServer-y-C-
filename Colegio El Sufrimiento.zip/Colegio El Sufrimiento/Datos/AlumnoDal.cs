﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Entidades;

namespace Datos
{
    public class AlumnoDal
    {
        string parametroC = "Data Source= DESKTOP-G3H6GVS\\SQLEXPRESS; Initial Catalog= Colegio; Integrated Security=True";
        string query = "";

        public void Insert(EAlumno alumno){
        
            SqlConnection conexion = new SqlConnection();
            conexion.ConnectionString = parametroC;

            conexion.Open();
            query = "INSERT INTO Alumno (Carnet, Nombre, Apellido) VALUES (@carnet, @nombre, @apellido)";

            using (SqlCommand cmd = new SqlCommand(query, conexion))
            {
                cmd.Parameters.AddWithValue("@carnet", alumno.Carnet);
                cmd.Parameters.AddWithValue("@nombre", alumno.Nombre);
                cmd.Parameters.AddWithValue("@apellido", alumno.Apellido);

                cmd.ExecuteNonQuery();
            }       
        }

        public List<EAlumno> GetAll()
        { 
            List<EAlumno> alumnos = new List<EAlumno>();
            SqlConnection conexion = new SqlConnection();
            conexion.ConnectionString = parametroC;
            conexion.Open();

            query = "SELECT * FROM Alumno ORDER BY Carnet ASC";

            using (SqlCommand cmd = new SqlCommand(query, conexion)) 
            {
                SqlDataReader reading = cmd.ExecuteReader();

                while (reading.Read()) 
                {
                    EAlumno alumno = new EAlumno
                    {
                        Carnet = Convert.ToInt32(reading["Carnet"]),
                        Nombre = Convert.ToString(reading["Nombre"]),
                        Apellido = Convert.ToString(reading["Apellido"])
                    };
                    alumnos.Add(alumno);
                }
            }
            return alumnos;
        }

        public EAlumno GetById(int carnetAlumno)
        {
            SqlConnection conexion = new SqlConnection();
            conexion.ConnectionString = parametroC;
            conexion.Open();

            query = "Select * from Alumno Where Carnet = @carnet";

            using (SqlCommand cmd = new SqlCommand(query, conexion)) 
            {
                cmd.Parameters.AddWithValue("@carnet", carnetAlumno);

                SqlDataReader reading = cmd.ExecuteReader();

                if (reading.Read()) 
                {
                    EAlumno alumno = new EAlumno
                    {
                        Carnet = Convert.ToInt32(reading["Carnet"]),
                        Nombre = Convert.ToString(reading["Nombre"]),
                        Apellido = Convert.ToString(reading["Apellido"])
                    };
                    return alumno;
                }
            }
            return null;
        }

        public void Update(EAlumno alumno) 
        {
            SqlConnection conexion = new SqlConnection();

            conexion.ConnectionString = parametroC;
            conexion.Open();

            query = "Update Alumno SET nombre = @nombre, apellido = @apellido Where Carnet = @carnet";
            
            using (SqlCommand cmd = new SqlCommand(query,conexion))
            {
                cmd.Parameters.AddWithValue("@nombre", alumno.Nombre);
                cmd.Parameters.AddWithValue("@apellido", alumno.Apellido);

                cmd.ExecuteNonQuery();            
            }
        }

        public void Delete(int carnetAlumno) 
        {
            SqlConnection conexion = new SqlConnection();
            conexion.ConnectionString = parametroC;
            conexion.Open();

            query = "Delete from Alumno where Carnet = @carnet";

            using (SqlCommand cmd = new SqlCommand(query, conexion)) 
            {
                cmd.Parameters.AddWithValue("@carnet", carnetAlumno);
                cmd.ExecuteNonQuery();
            }
        }




    }
}
