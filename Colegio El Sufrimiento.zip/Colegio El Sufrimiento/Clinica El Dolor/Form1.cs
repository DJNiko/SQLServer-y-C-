﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Logica_Negocio;
using Entidades;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace Clinica_El_Dolor
{
    public partial class Form1 : Form
    {
        string parametroC = "Data Source= DESKTOP-G3H6GVS\\SQLEXPRESS; Initial Catalog= Colegio; Integrated Security=True";
        string query = "";
        private EAlumno _alumno;
        private readonly AlumnoBol alumno_bol = new AlumnoBol();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Guardar() 
        {
            try
            {
                if (_alumno == null) _alumno = new EAlumno();

                _alumno.Carnet = int.Parse(txtCarnet.Text);
                _alumno.Nombre = txtNombre.Text;
                _alumno.Apellido = txtApellido.Text;

                alumno_bol.Register(_alumno);

                if (alumno_bol.msj.Length != 0)
                {
                    MessageBox.Show(alumno_bol.msj.ToString(), "Para Continuar: ");
                }
                else
                {
                    MessageBox.Show("Alumno Registrado/Actualizado");
                    TraerTodos();
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(string.Format("Error: {0}", error.Message), "Error Inesperado");
            }

 
        }

        private void TraerTodos()         
        {
            List<EAlumno> alumnos = alumno_bol.All();

            if (alumnos.Count > 0)
            {
                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = alumnos;
                dataGridView1.Columns["carnet"].DataPropertyName = "Carnet";
                dataGridView1.Columns["nombre"].DataPropertyName = "Nombre";
                dataGridView1.Columns["apellido"].DataPropertyName = "Apellido";
            }
            else
            {
                MessageBox.Show("No Existen Alumnos Registrados");
            }
        }
        private void TraerTodos2()
        {
            List<EAlumno> alumnos = alumno_bol.All();

            if (alumnos.Count > 0)
            {
                dataGridView2.AutoGenerateColumns = true;
                dataGridView2.DataSource = alumnos;
                dataGridView2.Columns["carnet"].DataPropertyName = "Carnet";
                dataGridView2.Columns["nombre"].DataPropertyName = "Nombre";
                dataGridView2.Columns["apellido"].DataPropertyName = "Apellido";
            }
            else
            {
                MessageBox.Show("No Existen Alumnos Registrados");
            }
        }
       
        private void TraerPorCarnet(int carnet) 
        {
            try
            {
                _alumno = alumno_bol.GetByCarnet(carnet);

                if (_alumno != null)
                {
                    txtCarnet.Text = Convert.ToString(_alumno.Carnet);
                    txtNombre.Text = _alumno.Nombre;
                    txtApellido.Text = _alumno.Apellido;
                }
                else
                    MessageBox.Show("El Alumno Solicitado no Existe");
            }
            catch (Exception error)
            {
                MessageBox.Show(string.Format("Error: {0}", error.Message), "Error Inesperado");
            }
        }

        private void Eliminar(int carnet)
        {
            try
            {
                alumno_bol.deleteAlumno(carnet);
                MessageBox.Show("Alumno Eliminado satisfactoriamente");
                TraerTodos();
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }

        private void ImportExcel()         
        {
            string conexion = "Provider = Microsoft.ACE.Oledb.12.0; Data Source = C:/Users/DELL/Desktop/Progra V/Ejemplo2.xlsx; Extended Properties = \"Excel 12.0; HDR = YES\"";

            OleDbConnection conector = default(OleDbConnection);
            conector = new OleDbConnection(conexion);
            conector.Open();
            OleDbCommand consulta = default(OleDbCommand);
            consulta = new OleDbCommand("Select * from [Hoja1$]", conector);

            OleDbDataAdapter adaptador = new OleDbDataAdapter();
            adaptador.SelectCommand = consulta;
          
            DataSet ds = new DataSet();
           
            adaptador.Fill(ds);
           
            dataGridView1.DataSource = ds.Tables[0];

            conector.Close();
        }

        private void ExportExcel() 
        {
            SqlConnection cnx = new SqlConnection();
            cnx.ConnectionString = parametroC;
            query = "INSERT INTO Alumno (Carnet, Nombre, Apellido) VALUES (@carnet, @nombre, @apellido)";
            SqlCommand cmd = new SqlCommand(query,cnx);
            cnx.Open();

            try 
            {
                foreach (DataGridViewRow row in dataGridView1.Rows) 
                {
                    cmd.Parameters.Clear();
                    
                    cmd.Parameters.AddWithValue("@carnet", Convert.ToString(row.Cells[0].Value));
                    cmd.Parameters.AddWithValue("@nombre", Convert.ToString(row.Cells[1].Value));
                    cmd.Parameters.AddWithValue("@apellido", Convert.ToString(row.Cells[2].Value));

                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show(" Datos Agregados ");
            }
                catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
            
        }
        
        private void btnImport_Click(object sender, EventArgs e)
        {
            ImportExcel();
        }

        private void btnAddTable_Click(object sender, EventArgs e)
        {
           ExportExcel(); 
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Guardar();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtCarnet.Text))
            {
                Eliminar(Convert.ToInt32(txtCarnet.Text));
            }
        }

        private void btnUpList_Click(object sender, EventArgs e)
        {
            TraerTodos();
        }      
        
        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            ImportExcel();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ExportExcel();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            TraerTodos();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtCarnet.Text))
            {
                Eliminar(Convert.ToInt32(txtCarnet.Text));
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Guardar();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            TraerTodos2();
        }

       

      

        
      

       


        




    }
}

      /*  private EPaciente _paciente;
        private EMedico _medico;
        private Eespecialidades _especialidad;
        private ESexo _sexo;
        private EMiMismo _mimismo;


        private readonly PacienteBol paciente_bol = new PacienteBol();
        private readonly MedicosBol medico_bol = new MedicosBol();
        private readonly EspecialidadBol especialidad_bol = new EspecialidadBol();
        private readonly SexoBol sexo_bol = new SexoBol();
        private readonly MiMismoBol mimismo_bol = new MiMismoBol();
        private readonly SemestreBol semestre_bol = new SemestreBol();


        private void MostrarMenu()
        {
            tpMimismo.TabPages.Remove(tp_pacientes);
            tpMimismo.TabPages.Remove(tp_Medicos);
            tpMimismo.TabPages.Remove(tpEspecialidad);
            tpMimismo.TabPages.Remove(tabPage1);
            tpMimismo.TabPages.Insert(0, tpMenu);
        }
        private void MostrarMedicos()
        {
            tpMimismo.TabPages.Remove(tp_pacientes);
            tpMimismo.TabPages.Remove(tpMenu);
            tpMimismo.TabPages.Remove(tpEspecialidad);
            tpMimismo.TabPages.Insert(0, tp_Medicos);

            txtCodigoEmpleado.Visible = false;
            lblCodigoEmpleado.Visible = false;
            gbMedicos.Visible = false;

            TraerTodosMedicos();
            LlenarComboBoxMedicos();
            LlenarComboBoxEspecialidades();

            rdbAgregarMedico.Checked = false;
            txtCodigoEmpleado.Text = "";
            txtNombre2.Text = "";
            txtApellido2.Text = "";
            txtDireccion2.Text = "";
            txtTelefono2.Text = "";
            txtBusqueda2.Text = "";
            txtGeneroMostrar.Text = "";
        }
        private void MostrarPacientes()
        {
            tpMimismo.TabPages.Remove(tpMenu);
            tpMimismo.TabPages.Remove(tp_Medicos);
            tpMimismo.TabPages.Remove(tpEspecialidad);
            tpMimismo.TabPages.Insert(0,tp_pacientes);

            lblExpediente.Visible = false;
            gbPacientes.Visible = false;
            txtExpediente.Visible = false;

            TraerTodosPacientes();
            LlenarComboBox();
            LlenarComboBoxPaciente_Medicos();

            rdbAgregarPaciente.Checked = false;
        }
        private void MostrarEspecialidad()
        {
            tpMimismo.TabPages.Remove(tp_pacientes);
            tpMimismo.TabPages.Remove(tp_Medicos);
            tpMimismo.TabPages.Remove(tpMenu);
            tpMimismo.TabPages.Insert(0,tpEspecialidad);

            txtCodigoEspecialidad.Visible = false;
            lblCodigo.Visible = false;
            gbExpecialidades.Visible = false;

            TraerTodosEspecialidades();
            rbEspecialidad.Checked = false;
        }
       
       * private void MostrarMimismo()
        {
            tpMimismo.TabPages.Remove(tpMenu);
            tpMimismo.TabPages.Remove(tp_pacientes);
            tpMimismo.TabPages.Remove(tp_Medicos);
            tpMimismo.TabPages.Remove(tpEspecialidad);
            tpMimismo.TabPages.Insert(0, tabPage1);
            LlenarComboBoxExamen();
        }


        //Buton para ir a TapPage de Medicos 
        private void button1_Click(object sender, EventArgs e)
        {
            MostrarMedicos();
        }
        private void btnPacientes_Click(object sender, EventArgs e)
        {
            MostrarPacientes();
        }




        // Metodos para Guardar
        private void GuardarPaciente()
        {
            try
            {
                if (_paciente == null) _paciente = new EPaciente();

                _paciente.Expediente = int.Parse(txtExpediente.Text);
                _paciente.Nombres = txtNombre.Text;
                _paciente.Apellidos = txt_Apellidos.Text;
                _paciente.Direccion = txtDireccion.Text;
                _paciente.Telefono = int.Parse(txt_Telefono.Text);
                _paciente.CodigoSexo = Convert.ToInt32(cb_Genero.SelectedValue);
                _paciente.CodigoMedico = Convert.ToInt32(cbMedico.SelectedValue);

                txtBusqueda.Text = Convert.ToString(_paciente.Expediente);

                paciente_bol.RegistrarPaciente(_paciente);

                if (paciente_bol.mensaje.Length != 0)
                {
                    MessageBox.Show(paciente_bol.mensaje.ToString(), "Para Continuar: ");
                }
                else
                {
                    MessageBox.Show("Paciente Registrado");
                    TraerTodosPacientes();
                    rdbAgregarPaciente.Checked = false;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
                rdbAgregarPaciente.Checked = false;
            }
        }
        private void GuardarMedico()
        {
            try
            {
                if (_medico == null) _medico = new EMedico();

                _medico.CodigoEmpleado = int.Parse(txtCodigoEmpleado.Text);
                _medico.Nombres2 = txtNombre2.Text;
                _medico.Apellidos2 = txtApellido2.Text;
                _medico.Direccion2 = txtDireccion2.Text;
                _medico.Telefono2 = int.Parse(txtTelefono2.Text);
                _medico.CodigoSexo = Convert.ToInt32(cbGeneroM.SelectedValue);
                _medico.CodigoEspecialidad = Convert.ToInt32(cbEspecialidad.SelectedValue);

                txtBusqueda2.Text = Convert.ToString(_medico.CodigoEmpleado);

               medico_bol.RegistrarMedico(_medico);

                if (medico_bol.mensaje.Length != 0)
                {
                    MessageBox.Show(medico_bol.mensaje.ToString(), "Para Continuar: ");
                }
                else
                {
                    MessageBox.Show("Medico Registrado/Actualizado");
                    TraerTodosMedicos();                    
                    rdbAgregarMedico.Checked = false;
                    lblGenero.Visible = true;
                    lblEspecialidad.Visible = true;
                    txtEspecialidadMostrar.Visible = true;
                    txtGeneroMostrar.Visible = true;
                    
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }
        private void GuardarEspecialidad()
        {
            try
            {
                if (_especialidad == null) _especialidad = new Eespecialidades();

                _especialidad.Codigo = int.Parse(txtCodigoEspecialidad.Text);
                _especialidad.Especialidad = txtEspecialidad.Text;
                txtBusqueda3.Text = Convert.ToString(_especialidad.Codigo);

               especialidad_bol.RegistrarEspecialidad(_especialidad);

                if (especialidad_bol.mensaje.Length != 0)
                {
                    MessageBox.Show(especialidad_bol.mensaje.ToString(), "Para Continuar: ");
                }
                else
                {
                    MessageBox.Show("Especialidad Registrada/Actualizado");
                    MostrarMedicos();                  
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }
        private void GuardarMimismo()
        {
            try
            {
                if (_mimismo == null) _mimismo = new EMiMismo();

                _mimismo.Carne = int.Parse(txtCarne.Text);
                _mimismo.NombreCompleto = txtNombreCompleto.Text;
                _mimismo.Direccion = txtDireccionExamen.Text;
                _mimismo.codigo_semestre = Convert.ToInt32(cbSemestre.SelectedValue);
                

                mimismo_bol.RegistrarMimismo(_mimismo);

                if (mimismo_bol.mensaje.Length != 0)
                {
                    MessageBox.Show(mimismo_bol.mensaje.ToString(), "Para Continuar: ");
                }
                else
                {
                    MessageBox.Show("Registrado");                   
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
                rdbAgregarPaciente.Checked = false;
            }
        }




        // Metodos para Traer Todos y llenar DGV
        private void TraerTodosPacientes()
        {
            List<EPaciente> pacientes = paciente_bol.Todos_Pacientes();

            if (pacientes.Count > 0)
            {
               dgvPacientes.AutoGenerateColumns = true;
               dgvPacientes.DataSource = pacientes;

            }
            else
            {
                MessageBox.Show("No existen pacientes Registrados");
            }
        }
        private void TraerTodosMedicos()
        {
            List<EMedico> medicos = medico_bol.Todos_Medicos();

            if (medicos.Count > 0)
            {
                dgvMedicos.AutoGenerateColumns = true;
                dgvMedicos.DataSource = medicos;
            }
            else
            {
                MessageBox.Show("No existen pacientes Registrados");
            }
        }       
        private void TraerTodosEspecialidades()
        {
            List<Eespecialidades> especialidades = especialidad_bol.Todos_Especialidades();
           
            if (especialidades.Count > 0)
            {
                dgvEspecialidades.AutoGenerateColumns = true;
                dgvEspecialidades.DataSource = especialidades;
            }
            else
            {
                MessageBox.Show("No existen especialidades Registrados");
            }
        }
        private void LlenarComboBox()
        {                                      
                cb_Genero.DataSource = sexo_bol.Todos_Sexos();
                cb_Genero.DisplayMember = "Genero";
                cb_Genero.ValueMember = "Id";         
        }
        private void LlenarComboBoxMedicos()
        {
            cbGeneroM.DataSource = sexo_bol.Todos_Sexos();
            cbGeneroM.DisplayMember = "Genero";
            cbGeneroM.ValueMember = "Id";
        }
        private void LlenarComboBoxEspecialidades()
        {
            cbEspecialidad.DataSource = especialidad_bol.Todos_Especialidades();
            cbEspecialidad.DisplayMember = "Especialidad";
            cbEspecialidad.ValueMember = "Codigo";
        }
        private void LlenarComboBoxPaciente_Medicos()
        {
            cbMedico.DataSource = medico_bol.Todos_Medicos();
            cbMedico.DisplayMember = "Nombre_m";
            cbMedico.ValueMember = "codigoempleado";
        }
        private void LlenarComboBoxExamen()
        {
            cbSemestre.DataSource = semestre_bol.Todos_Semestres();
            cbSemestre.DisplayMember = "semestre";
            cbSemestre.ValueMember = "codigo";
        }


        // Metodos para Traer por ID
        private void TraerPorIDPacientes(int id)
        {
            try
            {
                _paciente = paciente_bol.Traer_Por_Id_Pacientes(id);

                if (_paciente != null)
                {
                    txtExpediente.Text = Convert.ToString(_paciente.Expediente);
                    txtNombre.Text = _paciente.Nombres;
                    txt_Apellidos.Text = _paciente.Apellidos;
                    txtDireccion.Text = _paciente.Direccion;
                    txt_Telefono.Text = Convert.ToString(_paciente.Telefono);
                    txtGenero.Text = _paciente.TipoSexo;
                }
                else

                    MessageBox.Show("El Paciente solicitado no existe");
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }
        private void TraerPorIDMedicos(int id)
        {
            try
            {
               _medico = medico_bol.Traer_Por_Id_Medicos(id);

                if (_medico != null)
                {
                    txtCodigoEmpleado.Text = Convert.ToString(_medico.CodigoEmpleado);
                    txtNombre2.Text = _medico.Nombres2;
                    txtApellido2.Text = _medico.Apellidos2;
                    txtDireccion2.Text = _medico.Direccion2;
                    txtTelefono2.Text = Convert.ToString(_medico.Telefono2);
                    txtGeneroMostrar.Text = _medico.TipoSexo;
                    txtEspecialidadMostrar.Text = _medico.EspecialidadMedico;
                }
                else

                    MessageBox.Show("El Medicos solicitado no existe");
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }
        private void TraerPorIDEspecialidades(int id)
        {
            try
            {
                _especialidad = especialidad_bol.Traer_Por_Id_Especialidades(id);

                if (_especialidad != null)
                {
                    txtCodigoEspecialidad.Text = Convert.ToString(_especialidad.Codigo);
                    txtEspecialidad.Text = _especialidad.Especialidad;
                }
                else

                    MessageBox.Show("La Especialidad solicitada no existe");
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }




        // Metodos para Eliminar 
        private void EliminarPaciente(int id)
        {
            try
            {
                paciente_bol.EliminarPaciente(id);
                MessageBox.Show("Paciente Eliminado satisfactoriamente");
                TraerTodosPacientes();
                txtExpediente.Text = "";
                txtNombre.Text = "";
                txt_Apellidos.Text = "";
                txtDireccion.Text = "";
                txt_Telefono.Text = "";
                txtGenero.Text = "";
                txtBusqueda.Text = "";
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }
        private void EliminarMedico(int id)
        {
            try
            {
                medico_bol.EliminarMedico(id);
                MessageBox.Show("Medico Eliminado satisfactoriamente");
                TraerTodosMedicos();
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }
        private void EliminarEspecialidad(int id)
        {
            try
            {
                especialidad_bol.EliminarEspecialidad(id);
                MessageBox.Show("Especialidad Eliminada satisfactoriamente");
                TraerTodosEspecialidades();
            }
            catch (Exception e)
            {
                MessageBox.Show(string.Format("Error: {0}", e.Message), "Error inesperado");
            }
        }






        // Botones del TapControl de Pacientes
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            GuardarPaciente();
            txtExpediente.Visible = false;
            lblExpediente.Visible = false;
            gbPacientes.Visible = false;
            label1.Visible = true;
            txtGenero.Visible = true;
        }
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtExpediente.Text))
            {
                EliminarPaciente(Convert.ToInt32(txtExpediente.Text));

            }
        }
        private void btnActualizarLista_Click(object sender, EventArgs e)
        {
            TraerTodosPacientes();
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtBusqueda.Text))
            {
                TraerPorIDPacientes(Convert.ToInt32(txtBusqueda.Text));
            }
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnRegreso_Click(object sender, EventArgs e)
        {
            MostrarMenu();
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            lblExpediente.Visible = false;
            txtExpediente.Visible = false;
            gbPacientes.Visible = false;
            txtGenero.Visible = true;
            label1.Visible = true;
            rdbAgregarPaciente.Checked = false;
            txtExpediente.Text = "";
            txtNombre.Text = "";
            txt_Apellidos.Text = "";
            txtDireccion.Text = "";
            txt_Telefono.Text = "";
            txtGenero.Text = "";
            txtBusqueda.Text = "";
        }
        //Evento de RadioButon 
        private void rdbAgregarPaciente_CheckedChanged(object sender, EventArgs e)
        {
            lblExpediente.Visible = true;
            txtExpediente.Visible = true;
            gbPacientes.Visible = true;

            txtGenero.Visible = false;
            label1.Visible = false;
            lblMostrarMedico.Visible = false;
            txtMostrarMedico.Visible = false;

            txtExpediente.Text = "";
            txtNombre.Text = "";
            txt_Apellidos.Text = "";
            txtDireccion.Text = "";
            txt_Telefono.Text = "";
            txtGenero.Text = "";
            txtBusqueda.Text = "";

        }



        // Botones del TapControl de Medicos
        private void btnAgregar2_Click(object sender, EventArgs e)
        {
            GuardarMedico();
            txtCodigoEmpleado.Visible = false;
            lblCodigoEmpleado.Visible = false;
            gbMedicos.Visible = false;
            txtCodigoEmpleado.Text = "";
            txtNombre2.Text = "";
            txtApellido2.Text = "";
            txtDireccion2.Text = "";
            txtTelefono2.Text = "";
            txtBusqueda2.Text = "";
        }
        private void btnEliminar2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtCodigoEmpleado.Text))
            {
                EliminarMedico(Convert.ToInt32(txtCodigoEmpleado.Text));
                txtCodigoEmpleado.Text = "";
                txtNombre2.Text = "";
                txtApellido2.Text = "";
                txtDireccion2.Text = "";
                txtTelefono2.Text = "";
                txtBusqueda2.Text = "";
                txtGeneroMostrar.Text = "";
                txtEspecialidadMostrar.Text = "";
              
            }
        }
        private void btnActualizarLista2_Click(object sender, EventArgs e)
        {
            TraerTodosMedicos();
        }
        private void btnBuscar2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtBusqueda2.Text))
            {
                TraerPorIDMedicos(Convert.ToInt32(txtBusqueda2.Text));
            }
        }
        private void btnSalir2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnRegreso2_Click(object sender, EventArgs e)
        {
            MostrarMenu();
        }
        private void btnModificar2_Click(object sender, EventArgs e)
        {
            txtCodigoEmpleado.Text = "";
            txtNombre2.Text = "";
            txtApellido2.Text = "";
            txtDireccion2.Text = "";
            txtTelefono2.Text = "";
            txtBusqueda2.Text = "";
            txtGeneroMostrar.Text = "";
            txtCodigoEmpleado.Visible = false;
            lblCodigoEmpleado.Visible = false;
            gbMedicos.Visible = false;
            rdbAgregarMedico.Checked = false;
        }
        private void btnAgregar_Especialidad_Click(object sender, EventArgs e)
        {
            MostrarEspecialidad();
            txtCodigoEspecialidad.Text = "";
            txtBusqueda3.Text = "";
            txtCodigoEspecialidad.Text = "";
            txtBusqueda3.Focus();
            txtCodigoEspecialidad.Visible = false;
            lblCodigo.Visible = false;
            gbMedicos.Visible = false;
            rdbAgregarMedico.Checked = false;
        }
        //Evento de RadioButon 
        private void rdbAgregarMedico_CheckedChanged(object sender, EventArgs e)
        {
            txtCodigoEmpleado.Visible = true;
            lblCodigoEmpleado.Visible = true;
            gbMedicos.Visible = true;

            lblGenero.Visible = false;
            lblEspecialidad.Visible = false;
            txtEspecialidadMostrar.Visible = false;
            txtGeneroMostrar.Visible = false;
        }


        // Botones del TapControl de Especialidades
        private void btnAgregar3_Click(object sender, EventArgs e)
        {
            GuardarEspecialidad();
            txtEspecialidad.Text = "";
            txtBusqueda3.Text = "";
        }
        private void btnEliminar3_Click(object sender, EventArgs e)
        {
            EliminarEspecialidad(Convert.ToInt32(txtCodigoEspecialidad.Text));
            txtEspecialidad.Text = "";
            txtCodigoEspecialidad.Text = "";
            txtBusqueda3.Text = "";
        }
        private void btnActuaizar3_Click(object sender, EventArgs e)
        {
            TraerTodosEspecialidades();
        }
        private void btnBuscar3_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtBusqueda3.Text))
            {
                TraerPorIDEspecialidades(Convert.ToInt32(txtBusqueda3.Text));
            }
        }
        private void btnSalir3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnRegreso3_Click(object sender, EventArgs e)
        {
            MostrarMedicos();
            lblEspecialidad.Visible = true;
            lblGenero.Visible = true;
            txtGeneroMostrar.Visible = true;
            txtEspecialidadMostrar.Visible = true;
        }
        private void rbEspecialidad_CheckedChanged(object sender, EventArgs e)
        {
            txtCodigoEspecialidad.Visible = true;
            lblCodigo.Visible = true;
            gbExpecialidades.Visible = true;
            txtCodigoEspecialidad.Text = "";
            txtBusqueda3.Text = "";
            txtEspecialidad.Text = "";
            txtCodigoEspecialidad.Focus();
        }
        private void btnCancelar3_Click(object sender, EventArgs e)
        {

            txtEspecialidad.Text = "";
            txtBusqueda3.Text = "";
            txtCodigoEspecialidad.Visible = false;
            lblCodigo.Visible = false;
            gbExpecialidades.Visible = false;

            rbEspecialidad.Checked = false;
        }

        private void lblGenero_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void btnExamen_Click(object sender, EventArgs e)
        {
            MostrarMimismo();
        }

    }
}
        */