﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;
using Entidades;

namespace Logica_Negocio
{
    public class AlumnoBol
    {
        private AlumnoDal alumno_dal = new AlumnoDal();
        public readonly StringBuilder msj = new StringBuilder();

        public void Register(EAlumno alumno)
        {
            if (ValidarAlumno(alumno))
            {
                if (alumno_dal.GetById(alumno.Carnet) == null)
                {
                    alumno_dal.Insert(alumno);
                }
                else
                    alumno_dal.Update(alumno);
            }
        }

        public List<EAlumno> All()        
        {
            return alumno_dal.GetAll();
        }

        public EAlumno GetByCarnet(int carnetAlumno)
        {
            msj.Clear();

            if (carnetAlumno == 0) msj.Append("Porfavor Proporcione un Carnet Valido");
            if (msj.Length == 0)
            {
                return alumno_dal.GetById(carnetAlumno);
            }
            return null;
        }

        public void deleteAlumno(int carnetAlumno)
        {
            msj.Clear();

            if(carnetAlumno  == 0 ) msj.Append("Porfavor Proporcione un Carnet Valido");
            if(msj.Length == 0)
            {
                alumno_dal.Delete(carnetAlumno);
            }
        }

        public bool ValidarAlumno(EAlumno alumno) 
        {
            msj.Clear();

            if (alumno.Carnet <= 0) msj.Append("El campo Carnet es obligatorio");
            if (string.IsNullOrEmpty(alumno.Nombre)) msj.Append("El campo Nombre es obligatorio");
            if (string.IsNullOrEmpty(alumno.Apellido)) msj.Append("El campo Apellido es obligatorio");

            return msj.Length == 0;
        }


    }
}
